
import React, { useState, useEffect, useMemo } from 'react';
import { Client, ViewState, User, Purchase } from './types';
import Dashboard from './components/Dashboard';
import ClientList from './components/ClientList';
import ClientForm from './components/ClientForm';
import AIInsights from './components/AIInsights';
import AuthScreen from './components/AuthScreen';
import { supabase } from './lib/supabase';
import { 
  UsersIcon, 
  ChartBarIcon, 
  ExclamationCircleIcon, 
  PlusIcon,
  ArrowLeftOnRectangleIcon,
  UserCircleIcon,
  CloudArrowUpIcon
} from '@heroicons/react/24/outline';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [clients, setClients] = useState<Client[]>([]);
  const [view, setView] = useState<ViewState>('dashboard');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | undefined>(undefined);
  const [loading, setLoading] = useState(true);

  // Escutar mudanças de autenticação
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setCurrentUser(session?.user ?? null);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setCurrentUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Buscar dados quando o usuário logar
  useEffect(() => {
    if (currentUser) {
      fetchClients();
    }
  }, [currentUser]);

  const fetchClients = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('clients')
      .select(`
        *,
        purchases (*)
      `);

    if (error) {
      console.error('Erro ao buscar clientes:', error);
    } else {
      // Ajustar o formato dos dados para o nosso tipo Client
      const formattedClients: Client[] = data.map((c: any) => ({
        id: c.id,
        name: c.name,
        phone: c.phone,
        purchases: c.purchases.map((p: any) => ({
          id: p.id,
          date: p.purchase_date,
          dueDate: p.due_date,
          productName: p.product_name,
          quantity: p.quantity,
          price: parseFloat(p.price),
          isPaid: p.is_paid
        }))
      }));
      setClients(formattedClients);
    }
    setLoading(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setCurrentUser(null);
  };

  const addOrUpdateClient = async (clientData: Omit<Client, 'id'>) => {
    setLoading(true);
    if (editingClient) {
      // Atualizar cliente básico
      await supabase.from('clients').update({
        name: clientData.name,
        phone: clientData.phone
      }).eq('id', editingClient.id);

      // Se houver uma nova compra no formulário, ela virá no array de purchases
      // O formulário de edição atual adiciona a nova compra ao array
      const newPurchases = clientData.purchases.filter(p => !p.id || p.id.length < 5); // IDs temporários são pequenos
      
      for (const p of newPurchases) {
        await supabase.from('purchases').insert({
          client_id: editingClient.id,
          product_name: p.productName,
          quantity: p.quantity,
          price: p.price,
          purchase_date: p.date,
          due_date: p.dueDate,
          is_paid: p.isPaid
        });
      }
    } else {
      // Novo cliente
      const { data: newClient, error: clientErr } = await supabase.from('clients').insert({
        name: clientData.name,
        phone: clientData.phone,
        user_id: currentUser.id
      }).select().single();

      if (!clientErr && newClient) {
        // Inserir compras iniciais
        for (const p of clientData.purchases) {
          await supabase.from('purchases').insert({
            client_id: newClient.id,
            product_name: p.productName,
            quantity: p.quantity,
            price: p.price,
            purchase_date: p.date,
            due_date: p.dueDate,
            is_paid: p.isPaid
          });
        }
      }
    }
    await fetchClients();
    setIsFormOpen(false);
    setEditingClient(undefined);
  };

  const deleteClient = async (id: string) => {
    if (confirm('Deseja excluir este cliente e todo seu histórico permanentemente na nuvem?')) {
      await supabase.from('clients').delete().eq('id', id);
      await fetchClients();
    }
  };

  const togglePaymentStatus = async (clientId: string, purchaseId: string) => {
    const purchase = clients.find(c => c.id === clientId)?.purchases.find(p => p.id === purchaseId);
    if (purchase) {
      await supabase.from('purchases').update({ is_paid: !purchase.isPaid }).eq('id', purchaseId);
      await fetchClients();
    }
  };

  const pendingClientsCount = useMemo(() => 
    clients.filter(c => c.purchases.some(p => !p.isPaid && new Date(p.dueDate) < new Date())).length, 
  [clients]);

  if (!currentUser && !loading) {
    return <AuthScreen onLogin={() => {}} />;
  }

  if (loading && !currentUser) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50 text-indigo-600 font-bold">Carregando sistema seguro...</div>;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <nav className="w-full md:w-64 bg-indigo-900 text-white p-6 flex flex-col gap-8 shadow-xl z-20">
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-white p-2 rounded-lg">
            <UsersIcon className="w-8 h-8 text-indigo-900" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">ClientPro <span className="text-[10px] bg-indigo-500 px-1 rounded">CLOUD</span></h1>
        </div>

        <div className="flex flex-col gap-2 flex-grow">
          <button onClick={() => setView('dashboard')} className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${view === 'dashboard' ? 'bg-indigo-700 shadow-inner' : 'hover:bg-indigo-800'}`}>
            <ChartBarIcon className="w-5 h-5" />
            <span>Dashboard</span>
          </button>
          <button onClick={() => setView('clients')} className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${view === 'clients' ? 'bg-indigo-700 shadow-inner' : 'hover:bg-indigo-800'}`}>
            <UsersIcon className="w-5 h-5" />
            <span>Clientes</span>
          </button>
          <button onClick={() => setView('pending')} className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${view === 'pending' ? 'bg-indigo-700 shadow-inner' : 'hover:bg-indigo-800'}`}>
            <ExclamationCircleIcon className="w-5 h-5" />
            <span>Atrasados</span>
            {pendingClientsCount > 0 && <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">{pendingClientsCount}</span>}
          </button>
        </div>

        <div className="pt-4 border-t border-indigo-800 space-y-6">
           <AIInsights clients={clients} />
           
           <div className="bg-indigo-800/50 p-4 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-2 overflow-hidden">
                <UserCircleIcon className="w-6 h-6 flex-shrink-0" />
                <span className="text-xs font-medium truncate">{currentUser?.email}</span>
              </div>
              <button onClick={handleLogout} className="p-1.5 hover:bg-indigo-700 rounded-lg transition-colors text-indigo-300">
                <ArrowLeftOnRectangleIcon className="w-5 h-5" />
              </button>
           </div>
           <div className="flex items-center justify-center gap-2 text-[10px] text-indigo-400 font-bold uppercase">
              <CloudArrowUpIcon className="w-3 h-3" /> Conectado à Nuvem
           </div>
        </div>
      </nav>

      <main className="flex-grow p-4 md:p-10 overflow-auto bg-slate-50 z-10">
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-800 capitalize">
              {view === 'dashboard' ? 'Painel Geral' : view === 'clients' ? 'Meus Clientes' : 'Pagamentos Vencidos'}
            </h2>
            <p className="text-slate-500 mt-1">Gerenciamento em tempo real com banco de dados.</p>
          </div>
          <button 
            onClick={() => { setEditingClient(undefined); setIsFormOpen(true); }}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl flex items-center justify-center gap-2 font-semibold shadow-lg transition-all active:scale-95"
          >
            <PlusIcon className="w-5 h-5" />
            Nova Venda
          </button>
        </header>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
             <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
             Sincronizando com o banco...
          </div>
        ) : (
          <>
            {view === 'dashboard' && <Dashboard clients={clients} onTogglePayment={togglePaymentStatus} />}
            {view === 'clients' && <ClientList clients={clients} onDelete={deleteClient} onEdit={(c) => { setEditingClient(c); setIsFormOpen(true); }} onTogglePayment={togglePaymentStatus} />}
            {view === 'pending' && <ClientList clients={clients} onDelete={deleteClient} onEdit={(c) => { setEditingClient(c); setIsFormOpen(true); }} onTogglePayment={togglePaymentStatus} showOnlyPending />}
          </>
        )}

        {isFormOpen && (
          <ClientForm client={editingClient} onSubmit={addOrUpdateClient} onClose={() => setIsFormOpen(false)} />
        )}
      </main>
    </div>
  );
};

export default App;
