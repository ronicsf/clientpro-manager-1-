
import React, { useState } from 'react';
import { Client, Purchase } from '../types';
import { 
  PencilSquareIcon, 
  TrashIcon, 
  PhoneIcon, 
  CheckCircleIcon,
  XCircleIcon,
  MagnifyingGlassIcon,
  ClockIcon,
  QueueListIcon,
  CurrencyDollarIcon
} from '@heroicons/react/24/outline';
import PurchaseHistoryModal from './PurchaseHistoryModal';

interface ClientListProps {
  clients: Client[];
  onDelete: (id: string) => void;
  onEdit: (client: Client) => void;
  onTogglePayment: (clientId: string, purchaseId: string) => void;
  showOnlyPending?: boolean;
}

const ClientList: React.FC<ClientListProps> = ({ clients, onDelete, onEdit, onTogglePayment, showOnlyPending }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedHistoryClient, setSelectedHistoryClient] = useState<Client | null>(null);

  const isOverdue = (date: string) => new Date(date) < new Date();

  const getLatestPurchase = (client: Client) => {
    if (client.purchases.length === 0) return null;
    return [...client.purchases].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
  };

  const filteredClients = clients.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.purchases.some(p => p.productName.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (showOnlyPending) {
      return matchesSearch && c.purchases.some(p => !p.isPaid && isOverdue(p.dueDate));
    }
    return matchesSearch;
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
      <div className="p-4 border-b border-slate-100 flex items-center gap-3">
        <MagnifyingGlassIcon className="w-5 h-5 text-slate-400" />
        <input 
          type="text" 
          placeholder="Buscar por nome, produto..." 
          className="flex-grow focus:outline-none text-slate-700"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 text-slate-500 uppercase text-xs font-bold tracking-wider">
              <th className="px-6 py-4">Cliente</th>
              <th className="px-6 py-4">Última Compra</th>
              <th className="px-6 py-4">Status Geral</th>
              <th className="px-6 py-4 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredClients.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-6 py-10 text-center text-slate-400">
                  Nenhum cliente encontrado.
                </td>
              </tr>
            ) : (
              filteredClients.map((client) => {
                const latest = getLatestPurchase(client);
                const hasPending = client.purchases.some(p => !p.isPaid);
                const hasOverdue = client.purchases.some(p => !p.isPaid && isOverdue(p.dueDate));

                return (
                  <tr key={client.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-800">{client.name}</div>
                      <div className="flex items-center gap-1 text-slate-500 text-sm mt-0.5">
                        <PhoneIcon className="w-3.5 h-3.5" />
                        {client.phone}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {latest ? (
                        <>
                          <div className="text-slate-700 font-medium">{latest.productName}</div>
                          <div className="text-slate-400 text-xs">
                            {new Date(latest.date).toLocaleDateString('pt-BR')} • R$ {(latest.price * latest.quantity).toFixed(2)}
                          </div>
                        </>
                      ) : (
                        <span className="text-slate-300 italic">Sem compras</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-2">
                        {hasOverdue ? (
                          <span className="bg-red-100 text-red-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase">Atrasado</span>
                        ) : hasPending ? (
                          <span className="bg-amber-100 text-amber-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase">Pendente</span>
                        ) : (
                          <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase">Em dia</span>
                        )}
                        <span className="bg-indigo-50 text-indigo-600 text-[10px] font-bold px-2 py-1 rounded-full">
                          {client.purchases.length} compra(s)
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {latest && (
                          <button 
                            onClick={() => onTogglePayment(client.id, latest.id)}
                            title={latest.isPaid ? "Marcar como Pendente" : "Marcar como Pago"}
                            className={`p-2 rounded-lg transition-colors ${
                              latest.isPaid 
                              ? 'text-green-600 hover:bg-green-50' 
                              : 'text-amber-600 hover:bg-amber-50'
                            }`}
                          >
                            <CurrencyDollarIcon className="w-5 h-5" />
                          </button>
                        )}
                        <button 
                          onClick={() => setSelectedHistoryClient(client)}
                          title="Ver Histórico"
                          className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg"
                        >
                          <QueueListIcon className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => onEdit(client)}
                          title="Editar Cadastro"
                          className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                        >
                          <PencilSquareIcon className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => onDelete(client.id)}
                          title="Excluir"
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                        >
                          <TrashIcon className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {selectedHistoryClient && (
        <PurchaseHistoryModal 
          client={selectedHistoryClient} 
          onClose={() => setSelectedHistoryClient(null)} 
          onTogglePayment={onTogglePayment}
        />
      )}
    </div>
  );
};

export default ClientList;
