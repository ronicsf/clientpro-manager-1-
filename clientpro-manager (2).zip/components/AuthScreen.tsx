
import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { UsersIcon, EnvelopeIcon, LockClosedIcon, UserIcon, ArrowRightIcon } from '@heroicons/react/24/outline';

interface AuthScreenProps {
  onLogin: (user: any) => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const email = formData.email.trim().toLowerCase();
    const password = formData.password.trim();

    try {
      if (isRegistering) {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { display_name: formData.name }
          }
        });
        if (signUpError) throw signUpError;
        alert('Cadastro realizado! Verifique seu e-mail ou faça login (se o auto-confirm estiver ativo).');
        setIsRegistering(false);
      } else {
        const { data, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        if (signInError) throw signInError;
        if (data.user) onLogin(data.user);
      }
    } catch (err: any) {
      setError(err.message || 'Erro na autenticação');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-[600px]">
        <div className="md:w-1/2 bg-indigo-900 p-12 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="relative z-10">
            <div className="bg-white p-3 rounded-2xl inline-block mb-8">
              <UsersIcon className="w-10 h-10 text-indigo-900" />
            </div>
            <h2 className="text-4xl font-black leading-tight mb-4">
              Gerencie seus clientes na <span className="text-indigo-400">nuvem</span>.
            </h2>
            <p className="text-indigo-200 text-lg">
              Agora integrado com Banco de Dados PostgreSQL profissional.
            </p>
          </div>
          <div className="relative z-10 flex gap-4 text-sm font-medium text-indigo-300">
             <span>Supabase Cloud</span>
             <span>•</span>
             <span>PostgreSQL Real</span>
          </div>
          <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-indigo-800 rounded-full blur-3xl opacity-50"></div>
        </div>

        <div className="md:w-1/2 p-12 flex flex-col justify-center">
          <div className="mb-10 text-center md:text-left">
            <h3 className="text-3xl font-bold text-slate-800 mb-2">
              {isRegistering ? 'Criar conta segura' : 'Acesse seu painel'}
            </h3>
            <p className="text-slate-500">
              Dados protegidos e sincronizados.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {isRegistering && (
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input required type="text" placeholder="Seu nome" className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-500" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
              </div>
            )}

            <div className="relative">
              <EnvelopeIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input required type="email" placeholder="E-mail" className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-500" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} />
            </div>

            <div className="relative">
              <LockClosedIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input required type="password" placeholder="Senha" className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-500" value={formData.password} onChange={e => setFormData({ ...formData, password: e.target.value })} />
            </div>

            {error && <div className="text-red-600 text-sm font-bold text-center bg-red-50 p-4 rounded-2xl border border-red-100">{error}</div>}

            <button type="submit" disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] disabled:opacity-50">
              {loading ? 'Processando...' : (isRegistering ? 'Cadastrar Agora' : 'Entrar no Sistema')}
              <ArrowRightIcon className="w-5 h-5" />
            </button>
          </form>

          <button onClick={() => setIsRegistering(!isRegistering)} className="mt-8 text-slate-500 hover:text-indigo-600 font-medium w-full text-center">
            {isRegistering ? 'Já tem conta? Login' : 'Não tem conta? Cadastre-se'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
