
import React from 'react';
import { Client } from '../types';
import { 
  CurrencyDollarIcon, 
  UserGroupIcon, 
  ClockIcon,
  BanknotesIcon,
  ArrowTrendingUpIcon,
  // Added missing ShoppingCartIcon import
  ShoppingCartIcon
} from '@heroicons/react/24/outline';

interface DashboardProps {
  clients: Client[];
  onTogglePayment: (clientId: string, purchaseId: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ clients }) => {
  const totalClients = clients.length;
  
  let totalSales = 0; // Total accumulated sales (ever sold)
  let totalRevenue = 0; // Total paid
  let totalPending = 0; // Total to receive
  let overdueCount = 0;

  const isOverdue = (date: string) => new Date(date) < new Date();

  clients.forEach(c => {
    c.purchases.forEach(p => {
      const amount = p.price * p.quantity;
      totalSales += amount;
      if (p.isPaid) {
        totalRevenue += amount;
      } else {
        totalPending += amount;
        if (isOverdue(p.dueDate)) {
          overdueCount++;
        }
      }
    });
  });

  const stats = [
    { label: 'Total de Vendas', value: `R$ ${totalSales.toFixed(2)}`, icon: ArrowTrendingUpIcon, color: 'text-indigo-600', bg: 'bg-indigo-50', sub: 'Volume bruto negociado' },
    { label: 'Vendas Pagas', value: `R$ ${totalRevenue.toFixed(2)}`, icon: BanknotesIcon, color: 'text-green-600', bg: 'bg-green-50', sub: 'Dinheiro em caixa' },
    { label: 'Valores Pendentes', value: `R$ ${totalPending.toFixed(2)}`, icon: CurrencyDollarIcon, color: 'text-amber-600', bg: 'bg-amber-50', sub: 'Aguardando recebimento' },
    { label: 'Faturas Vencidas', value: overdueCount, icon: ClockIcon, color: 'text-red-600', bg: 'bg-red-50', sub: 'Atenção necessária' },
  ];

  const allPurchases = clients.flatMap(c => c.purchases.map(p => ({ ...p, clientName: c.name })))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-4">
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-xl ${stat.bg}`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <p className="text-sm font-semibold text-slate-500">{stat.label}</p>
            </div>
            <div>
              <p className="text-2xl font-black text-slate-800 tracking-tight">{stat.value}</p>
              <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-widest">{stat.sub}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Transactions */}
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-800">Últimas Movimentações</h3>
            <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
              Mostrando {Math.min(allPurchases.length, 5)} de {allPurchases.length}
            </span>
          </div>
          <div className="space-y-4">
            {allPurchases.slice(0, 5).map((p, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 rounded-xl border border-slate-50 hover:bg-slate-50 transition-colors group">
                <div className="flex gap-4 items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${p.isPaid ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                    {p.clientName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">{p.clientName}</h4>
                    <p className="text-xs text-slate-500">{p.productName} • {p.quantity} unid.</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-slate-800">R$ {(p.price * p.quantity).toFixed(2)}</p>
                  <p className={`text-[10px] font-bold ${p.isPaid ? 'text-green-500' : 'text-amber-500'}`}>
                    {p.isPaid ? 'RECEBIDO' : 'AGUARDANDO'}
                  </p>
                </div>
              </div>
            ))}
            {allPurchases.length === 0 && (
              <div className="text-center py-12 flex flex-col items-center gap-3">
                <ShoppingCartIcon className="w-12 h-12 text-slate-200" />
                <p className="text-slate-400">Nenhuma venda registrada ainda.</p>
              </div>
            )}
          </div>
        </div>

        {/* Financial Alerts */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-xl font-bold text-slate-800 mb-6">Metas e Recebíveis</h3>
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
               <div className="flex justify-between text-xs font-bold text-slate-400 mb-2">
                 <span>PROGRESSO DE RECEBIMENTOS</span>
                 <span>{totalSales > 0 ? ((totalRevenue / totalSales) * 100).toFixed(0) : 0}%</span>
               </div>
               <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                 <div 
                   className="bg-indigo-600 h-full transition-all duration-1000" 
                   style={{ width: `${totalSales > 0 ? (totalRevenue / totalSales) * 100 : 0}%` }}
                 ></div>
               </div>
            </div>

            {overdueCount > 0 ? (
              <div className="bg-red-50 p-4 rounded-xl border border-red-100 flex items-start gap-3">
                <ClockIcon className="w-5 h-5 text-red-500 mt-0.5" />
                <div>
                  <p className="text-red-700 font-semibold text-sm">Alerta de Inadimplência</p>
                  <p className="text-xs text-red-600 leading-tight mt-1">
                    Você possui {overdueCount} vendas com prazo de pagamento expirado.
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-green-50 p-4 rounded-xl border border-green-100 flex items-start gap-3">
                <BanknotesIcon className="w-5 h-5 text-green-500 mt-0.5" />
                <div>
                  <p className="text-green-700 font-semibold text-sm">Finanças Saudáveis</p>
                  <p className="text-xs text-green-600 leading-tight mt-1">
                    Todos os seus recebíveis pendentes ainda estão dentro do prazo de vencimento.
                  </p>
                </div>
              </div>
            )}
            
            <div className="mt-8">
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Agenda de Faturas</h4>
              <div className="space-y-3">
                {allPurchases
                  .filter(p => !p.isPaid && !isOverdue(p.dueDate))
                  .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
                  .slice(0, 4)
                  .map((p, i) => (
                    <div key={i} className="flex justify-between items-center text-xs py-2 border-b border-slate-50 hover:bg-slate-50 px-1 rounded transition-colors">
                      <span className="text-slate-700 font-medium truncate max-w-[120px]">{p.clientName}</span>
                      <div className="text-right">
                        <span className="text-indigo-600 font-bold block">{new Date(p.dueDate).toLocaleDateString()}</span>
                        <span className="text-[9px] text-slate-400">R$ {(p.price * p.quantity).toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
