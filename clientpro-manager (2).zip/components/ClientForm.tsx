
import React, { useState, useEffect } from 'react';
import { Client, Purchase } from '../types';
import { XMarkIcon, UserIcon, ShoppingCartIcon, CurrencyDollarIcon } from '@heroicons/react/24/outline';

interface ClientFormProps {
  client?: Client;
  onSubmit: (clientData: Omit<Client, 'id'>) => void;
  onClose: () => void;
}

const ClientForm: React.FC<ClientFormProps> = ({ client, onSubmit, onClose }) => {
  const [basicInfo, setBasicInfo] = useState({
    name: '',
    phone: ''
  });

  const [newPurchase, setNewPurchase] = useState({
    productName: '',
    quantity: 1,
    price: 0,
    date: new Date().toISOString().split('T')[0],
    dueDate: '',
    isPaid: false
  });

  useEffect(() => {
    if (client) {
      setBasicInfo({ name: client.name, phone: client.phone });
    }
  }, [client]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (client) {
      const updatedPurchases = [...client.purchases];
      if (newPurchase.productName) {
        updatedPurchases.push({
          ...newPurchase,
          id: Math.random().toString(36).substr(2, 9)
        });
      }
      onSubmit({ ...basicInfo, purchases: updatedPurchases });
    } else {
      const initialPurchase: Purchase = {
        ...newPurchase,
        id: Math.random().toString(36).substr(2, 9)
      };
      onSubmit({ ...basicInfo, purchases: [initialPurchase] });
    }
  };

  const purchaseTotal = (newPurchase.quantity * newPurchase.price).toFixed(2);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 flex flex-col max-h-[90vh]">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-indigo-50">
          <h3 className="text-xl font-bold text-indigo-900 flex items-center gap-2">
            {client ? 'Editar Cliente' : 'Novo Cliente & Venda'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-full transition-colors">
            <XMarkIcon className="w-6 h-6 text-slate-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto p-8 space-y-8">
          {/* Section: Basic Info */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              <UserIcon className="w-4 h-4" /> Informações do Cliente
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Nome Completo</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-500"
                  value={basicInfo.name}
                  onChange={e => setBasicInfo({ ...basicInfo, name: e.target.value })}
                  placeholder="Ex: Maria Oliveira"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Telefone / WhatsApp</label>
                <input 
                  required
                  type="tel" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-500"
                  value={basicInfo.phone}
                  onChange={e => setBasicInfo({ ...basicInfo, phone: e.target.value })}
                  placeholder="(00) 00000-0000"
                />
              </div>
            </div>
          </div>

          {/* Section: Purchase Detail */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <ShoppingCartIcon className="w-4 h-4" /> {client ? 'Adicionar Nova Compra' : 'Detalhes da Primeira Venda'}
              </h4>
              {newPurchase.productName && (
                <div className="bg-indigo-600 text-white px-3 py-1 rounded-lg text-sm font-bold animate-pulse">
                  Total desta venda: R$ {purchaseTotal}
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50 p-6 rounded-2xl border border-dashed border-slate-300">
              <div className="md:col-span-2">
                <label className="block text-sm font-bold text-slate-700 mb-2">Produto ou Serviço</label>
                <input 
                  required={!client}
                  type="text" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-500"
                  value={newPurchase.productName}
                  onChange={e => setNewPurchase({ ...newPurchase, productName: e.target.value })}
                  placeholder="O que o cliente está levando?"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Quantidade</label>
                <input 
                  required={!client}
                  type="number" 
                  min="1"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-500"
                  value={newPurchase.quantity}
                  onChange={e => setNewPurchase({ ...newPurchase, quantity: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Preço Unitário (R$)</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-slate-400 text-sm">R$</span>
                  </div>
                  <input 
                    required={!client}
                    type="number" 
                    step="0.01"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-500"
                    value={newPurchase.price}
                    onChange={e => setNewPurchase({ ...newPurchase, price: parseFloat(e.target.value) || 0 })}
                    placeholder="0,00"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Data da Compra</label>
                <input 
                  required={!client}
                  type="date" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-500"
                  value={newPurchase.date}
                  onChange={e => setNewPurchase({ ...newPurchase, date: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Vencimento Pagamento</label>
                <input 
                  required={!client}
                  type="date" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-500"
                  value={newPurchase.dueDate}
                  onChange={e => setNewPurchase({ ...newPurchase, dueDate: e.target.value })}
                />
              </div>

              <div className="md:col-span-3 flex items-center gap-3 bg-white p-4 rounded-xl border border-slate-100">
                <input 
                  type="checkbox" 
                  id="isPaidForm"
                  className="w-5 h-5 text-indigo-600 rounded cursor-pointer"
                  checked={newPurchase.isPaid}
                  onChange={e => setNewPurchase({ ...newPurchase, isPaid: e.target.checked })}
                />
                <label htmlFor="isPaidForm" className="text-sm font-bold text-slate-700 cursor-pointer">
                  Esta compra já foi paga?
                </label>
              </div>
            </div>
            
            <div className="mt-4 flex justify-end">
               <div className="bg-indigo-50 border border-indigo-100 px-6 py-3 rounded-2xl flex items-center gap-4 shadow-sm">
                  <div className="text-xs font-bold text-indigo-400 uppercase tracking-widest">Resumo do Pedido</div>
                  <div className="text-xl font-black text-indigo-900">R$ {purchaseTotal}</div>
               </div>
            </div>

            {client && (
              <p className="mt-3 text-[10px] text-slate-400 italic">
                Deixe os campos de produto em branco se desejar alterar apenas o nome ou telefone do cliente.
              </p>
            )}
          </div>

          <div className="flex gap-4 sticky bottom-0 bg-white pt-4 pb-2 border-t border-slate-100">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 rounded-xl border border-slate-200 font-semibold text-slate-600 hover:bg-slate-50 transition-all"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-1 px-6 py-3 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all"
            >
              {client ? 'Atualizar Dados' : 'Finalizar Cadastro'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ClientForm;
