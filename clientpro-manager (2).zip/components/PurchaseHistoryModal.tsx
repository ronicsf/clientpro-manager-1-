
import React from 'react';
import { Client, Purchase } from '../types';
import { 
  XMarkIcon, 
  ShoppingBagIcon, 
  CalendarIcon, 
  CurrencyDollarIcon, 
  CheckCircleIcon, 
  ClockIcon 
} from '@heroicons/react/24/outline';

interface PurchaseHistoryModalProps {
  client: Client;
  onClose: () => void;
  onTogglePayment: (clientId: string, purchaseId: string) => void;
}

const PurchaseHistoryModal: React.FC<PurchaseHistoryModalProps> = ({ client, onClose, onTogglePayment }) => {
  const sortedPurchases = [...client.purchases].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const totalSpent = client.purchases.reduce((acc, p) => acc + (p.price * p.quantity), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white h-full w-full max-w-md shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-right duration-300">
        <div className="px-6 py-6 border-b border-slate-100 bg-indigo-900 text-white">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Histórico de Compras</h3>
            <button onClick={onClose} className="p-2 hover:bg-indigo-800 rounded-full transition-colors">
              <XMarkIcon className="w-6 h-6" />
            </button>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-xl font-bold">
              {client.name.charAt(0)}
            </div>
            <div>
              <p className="font-semibold text-lg">{client.name}</p>
              <p className="text-indigo-200 text-sm">Total acumulado: R$ {totalSpent.toFixed(2)}</p>
            </div>
          </div>
        </div>

        <div className="flex-grow overflow-y-auto p-6 bg-slate-50">
          <div className="relative border-l-2 border-indigo-100 ml-4 space-y-8 pb-8">
            {sortedPurchases.map((purchase) => (
              <div key={purchase.id} className="relative pl-8">
                {/* Dot */}
                <div className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full border-4 border-white shadow-sm transition-colors ${purchase.isPaid ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                
                <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                      <CalendarIcon className="w-3 h-3" />
                      {new Date(purchase.date).toLocaleDateString('pt-BR')}
                    </span>
                    <button 
                      onClick={() => onTogglePayment(client.id, purchase.id)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase transition-colors hover:opacity-80 ${
                        purchase.isPaid ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                      }`}
                      title="Clique para alternar status"
                    >
                      {purchase.isPaid ? 'Pago' : 'Pendente'}
                    </button>
                  </div>
                  
                  <h4 className="font-bold text-slate-800 flex items-center gap-2">
                    <ShoppingBagIcon className="w-4 h-4 text-indigo-500" />
                    {purchase.productName}
                  </h4>
                  
                  <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                    <div className="text-slate-500">
                      Qtd: <span className="text-slate-800 font-medium">{purchase.quantity}</span>
                    </div>
                    <div className="text-slate-500">
                      Valor: <span className="text-indigo-600 font-bold">R$ {(purchase.price * purchase.quantity).toFixed(2)}</span>
                    </div>
                    <div className="col-span-2 text-xs text-slate-400 mt-1 flex items-center gap-1">
                      <ClockIcon className="w-3 h-3" />
                      Vencimento: {new Date(purchase.dueDate).toLocaleDateString('pt-BR')}
                    </div>
                  </div>

                  <button 
                    onClick={() => onTogglePayment(client.id, purchase.id)}
                    className={`mt-4 w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${
                      purchase.isPaid 
                      ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' 
                      : 'bg-green-600 text-white hover:bg-green-700 shadow-md shadow-green-100'
                    }`}
                  >
                    <CurrencyDollarIcon className="w-4 h-4" />
                    {purchase.isPaid ? 'Marcar como Pendente' : 'Marcar como Pago'}
                  </button>
                </div>
              </div>
            ))}
            {sortedPurchases.length === 0 && (
              <div className="text-center py-10 text-slate-400 italic">
                Nenhuma compra registrada.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PurchaseHistoryModal;
