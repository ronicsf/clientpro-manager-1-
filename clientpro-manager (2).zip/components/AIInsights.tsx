
import React, { useState } from 'react';
import { Client } from '../types';
import { analyzeClients } from '../services/geminiService';
import { SparklesIcon, ArrowPathIcon } from '@heroicons/react/24/solid';

interface AIInsightsProps {
  clients: Client[];
}

const AIInsights: React.FC<AIInsightsProps> = ({ clients }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (clients.length === 0) return;
    setLoading(true);
    const result = await analyzeClients(clients);
    setInsight(result);
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <button 
        onClick={handleAnalyze}
        disabled={loading || clients.length === 0}
        className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white p-3 rounded-xl font-bold text-sm shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
      >
        {loading ? (
          <ArrowPathIcon className="w-5 h-5 animate-spin" />
        ) : (
          <SparklesIcon className="w-5 h-5" />
        )}
        Análise Inteligente
      </button>

      {insight && (
        <div className="bg-indigo-950/50 backdrop-blur border border-indigo-700/50 p-4 rounded-xl text-xs text-indigo-100 leading-relaxed max-h-64 overflow-auto animate-in slide-in-from-bottom-2 duration-300">
          <div className="prose prose-invert prose-xs">
             <div dangerouslySetInnerHTML={{ __html: insight.replace(/\n/g, '<br/>') }} />
          </div>
        </div>
      )}
      
      {!insight && clients.length > 0 && !loading && (
        <p className="text-[10px] text-indigo-300 text-center italic">
          Clique para ver insights sobre sua carteira de clientes usando IA.
        </p>
      )}
    </div>
  );
};

export default AIInsights;
