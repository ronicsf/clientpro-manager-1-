
import { createClient } from '@supabase/supabase-js';

// Estas variáveis devem ser configuradas no seu painel da Vercel/Ambiente
const supabaseUrl = (process.env.SUPABASE_URL || 'https://sua-url.supabase.co');
const supabaseAnonKey = (process.env.SUPABASE_ANON_KEY || 'sua-chave-anon');

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
