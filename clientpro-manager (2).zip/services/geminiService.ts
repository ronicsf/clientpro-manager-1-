
import { GoogleGenAI } from "@google/genai";
import { Client, Purchase } from "../types";

export const analyzeClients = async (clients: Client[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const clientDataString = clients.map(c => {
    const purchaseSummary = c.purchases.map(p => 
      `- ${p.productName} (${p.quantity}x de R$ ${p.price}): Comprado em ${p.date}, Vencimento: ${p.dueDate}, Pago: ${p.isPaid ? 'Sim' : 'Não'}`
    ).join('\n  ');
    return `Cliente: ${c.name}\n  Histórico:\n  ${purchaseSummary}`;
  }).join('\n\n');

  const prompt = `Analise os seguintes dados de clientes e seu histórico de compras. Forneça um resumo estratégico em Português do Brasil.
  Foque em:
  1. Fluxo de caixa (total pago vs total pendente).
  2. Clientes mais valiosos (maior volume financeiro).
  3. Alertas de inadimplência.
  4. Sugestões de produtos que podem ser oferecidos com base no histórico.
  
  Use Markdown e emojis para tornar a leitura agradável.
  
  Dados:\n${clientDataString}`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text || "Não foi possível gerar a análise no momento.";
  } catch (error) {
    console.error("Gemini analysis error:", error);
    return "Erro ao processar análise inteligente.";
  }
};
