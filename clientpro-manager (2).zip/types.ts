
export interface User {
  id: string;
  name: string;
  email: string;
  password: string; // Em um app real, isso seria um hash
}

export interface Purchase {
  id: string;
  date: string;
  dueDate: string;
  productName: string;
  quantity: number;
  price: number;
  isPaid: boolean;
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  purchases: Purchase[];
}

export type ViewState = 'dashboard' | 'clients' | 'pending';

export interface BusinessInsight {
  summary: string;
  actionItems: string[];
  sentiment: 'positive' | 'neutral' | 'negative';
}
